
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {

    static class Car {
        private String marka;
        private String model;
        private int horsepower;

        public Car(String make, String model, int horsepower) {
            this.marka = marka;
            this.model = model;
            this.horsepower = horsepower;
        }

        public String getMake() {
            return marka;
        }

        public String getModel() {
            return model;
        }

        public int getHorsepower() {
            return horsepower;
        }
    }

    public static void main(String[] args) {
        List<Car> automobil = new ArrayList<>();
        automobil.add(new Car("Toyota ", " Camry   ", 200));
        automobil.add(new Car("Ford   ", " Mustang ", 180));
        automobil.add(new Car("BMW    ", " 3 Series", 450));
        automobil.add(new Car("Honda  ", " Civic   ", 150));
        automobil.add(new Car("Chevrolet ", "Silverado ", 350));
        automobil.add(new Car("Mercedes-Benz ", "E-Class", 450));
        automobil.add(new Car("Tesla ", "Model S", 150));
        automobil.add(new Car("Volkswagen", " Golf", 350));
        System.out.println("Automobilių sąrašas prieš rūšiavimą:");
        printCarList(automobil);

        // Сортировка по марке, модели и мощности
        sortCars(automobil);

        System.out.println("\nAutomobilių sąrašas po rūšiavimo:");
        printCarList(automobil);
    }

    public static void printCarList(List<Car> cars) {
        for (Car car : cars) {
            System.out.println(car.getMake() + " " + car.getModel() + " - " + car.getHorsepower() + " hp");
        }
    }

    public static void sortCars(List<Car> cars) {
        Comparator<Car> comparator = Comparator
                .comparing(Car::getMake)
                .thenComparing(Car::getModel)
                .thenComparingInt(Car::getHorsepower);

        Collections.sort(cars, comparator);
    }
}
