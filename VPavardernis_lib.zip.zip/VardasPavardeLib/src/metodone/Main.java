
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

        public class Main {
    
               static class Employee {
               private String name;
               private String profession;
        
                       public Employee(String name, String profession) {
                       this.name = name;
                       this.profession = profession;
                   }
        
                       public String getName() {
                       return name;
                   }
        
                       public String getProfession() {
                       return profession;
                   }
           }
    
               public static void main(String[] args) {
               List<Employee> employees = new ArrayList<>();
               employees.add(new Employee("Susan Hill", "Developer"));
               employees.add(new Employee("Barbara Ross", "Developer"));
               employees.add(new Employee("Justin Guerrero", "Designer"));
               employees.add(new Employee("Michelle Ramirez", "Manager"));
               employees.add(new Employee("Robert Erickson", "Designer"));
               employees.add(new Employee("Gerald Ferguson", "Designer"));
               employees.add(new Employee("Deborah Lambert", "Designer"));
               employees.add(new Employee("Karen Moore", "Developer"));
               employees.add(new Employee("Ruby Rodriguez", "Developer"));
               employees.add(new Employee("Felicia Collins", "Developer"));
               employees.add(new Employee("Anthony Williams", "Developer"));
        
               System.out.println("Darbuotojų sąrašas prieš rūšiavimą:");
               printEmployeeList(employees);
        
               // Сортировка по имени
               sortEmployeesAlphabetically(employees);
        
               System.out.println("\nDarbuotojų sąrašas surūšiavus abėcėlės tvarka:");
               printEmployeeList(employees);
        
               // Сортировка по профессии
               employees.sort(Comparator.comparing(Employee::getProfession));
        
               System.out.println("\nDarbuotojų sąrašas surūšiavus pagal profesiją:");
               printEmployeeList(employees);
           }
    
               public static void printEmployeeList(List<Employee> employees) {
               for (Employee employee : employees) {
                       System.out.println(employee.getName() + ": " + employee.getProfession());
                   }
           }
    
               public static void sortEmployeesAlphabetically(List<Employee> employees) {
               Collections.sort(employees, Comparator.comparing(Employee::getName));
           }
    }